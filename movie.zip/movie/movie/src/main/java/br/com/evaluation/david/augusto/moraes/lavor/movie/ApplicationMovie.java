package br.com.evaluation.david.augusto.moraes.lavor.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApplicationMovie
{

	public static void main(String[] args)
	{
		SpringApplication.run(ApplicationMovie.class, args);
	}

}
